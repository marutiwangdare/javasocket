/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.socketdemo;

/**
 *
 * @author King
 */
import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {
            // Create a socket and connect to the server
            Socket clientSocket = new Socket("localhost", 12345);
            System.out.println("Connected to server: " + clientSocket);

            // Create output streams for the socket
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            // Send a message to the server
            String message = "Hello from the client!";
            out.println(message);
            System.out.println("Sent to server: " + message);

           

            // Close the connections
            out.close();
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

